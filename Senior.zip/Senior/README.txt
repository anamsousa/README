Os arquivos .ipynb podem ser executados no Jupyter Notebook - Necessário utilizar o Anaconda e toda a pasta estar no mesmo local. 

